'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { useLanguage } from '../../../../contexts/LanguageContext'
import { getTranslation } from '../../../../lib/translations'
import AdminLayout from '../../../../components/admin/AdminLayout'
import CrudForm from '../../../../components/admin/CrudForm'
import { useFetchData } from '../../../../hooks'

export default function AddTeamMember() {
  const router = useRouter()
  const { language } = useLanguage()
  const [memberType, setMemberType] = useState('player')

  // Fetch team roles for dropdown
  const { data: roles } = useFetchData('/team-roles')

  useEffect(() => {
    if (!localStorage.getItem('adminAuth')) {
      router.push('/admin')
    }
  }, [router])

  const playerFields = [
    // Basic Information Section
    {
      name: 'name',
      label: 'Player Name',
      type: 'text',
      required: true,
      placeholder: 'Enter player name',
      section: 'Basic Information'
    },
    {
      name: 'slug',
      label: 'Slug',
      type: 'text',
      required: true,
      placeholder: 'player-slug',
      help: 'URL-friendly version of the name',
      section: 'Basic Information'
    },
    {
      name: 'jersey_number',
      label: 'Jersey Number',
      type: 'number',
      min: 1,
      max: 999,
      placeholder: 'Jersey number (optional)'
    },
    {
      name: 'role',
      label: 'Player Role',
      type: 'select',
      required: true,
      options: [
        { value: 'batsman', label: 'Batsman' },
        { value: 'bowler', label: 'Bowler' },
        { value: 'all-rounder', label: 'All-rounder' },
        { value: 'wicket-keeper', label: 'Wicket-keeper' }
      ]
    },
    {
      name: 'position',
      label: 'Position',
      type: 'text',
      placeholder: 'Playing position'
    },
    {
      name: 'age',
      label: 'Age',
      type: 'number',
      required: true,
      min: 16,
      max: 50
    },
    {
      name: 'date_of_birth',
      label: 'Date of Birth',
      type: 'date'
    },
    {
      name: 'photo',
      label: 'Player Photo',
      type: 'file',
      accept: 'image/*'
    },
    {
      name: 'bio',
      label: 'Biography',
      type: 'textarea',
      rows: 4,
      placeholder: 'Player biography',
      fullWidth: true
    },
    {
      name: 'matches_played',
      label: 'Matches Played',
      type: 'number',
      defaultValue: 0,
      min: 0
    },
    {
      name: 'runs_scored',
      label: 'Runs Scored',
      type: 'number',
      defaultValue: 0,
      min: 0
    },
    {
      name: 'wickets_taken',
      label: 'Wickets Taken',
      type: 'number',
      defaultValue: 0,
      min: 0
    },
    {
      name: 'batting_average',
      label: 'Batting Average',
      type: 'number',
      defaultValue: 0,
      min: 0,
      step: 0.01
    },
    {
      name: 'bowling_average',
      label: 'Bowling Average',
      type: 'number',
      defaultValue: 0,
      min: 0,
      step: 0.01
    },
    {
      name: 'strike_rate',
      label: 'Strike Rate',
      type: 'number',
      defaultValue: 0,
      min: 0,
      step: 0.01
    },
    {
      name: 'debut_date',
      label: 'Debut Date',
      type: 'date'
    },
    {
      name: 'join_date',
      label: 'Join Date',
      type: 'date',
      required: true
    },
    {
      name: 'status',
      label: 'Status',
      type: 'select',
      required: true,
      defaultValue: 'active',
      options: [
        { value: 'active', label: 'Active' },
        { value: 'injured', label: 'Injured' },
        { value: 'retired', label: 'Retired' },
        { value: 'suspended', label: 'Suspended' }
      ]
    },
    {
      name: 'is_captain',
      label: 'Captain',
      type: 'checkbox'
    },
    {
      name: 'is_vice_captain',
      label: 'Vice Captain',
      type: 'checkbox'
    },
    {
      name: 'is_featured',
      label: 'Featured Player',
      type: 'checkbox'
    }
  ]

  const memberFields = [
    {
      name: 'name',
      label: 'Member Name',
      type: 'text',
      required: true,
      placeholder: 'Enter member name'
    },
    {
      name: 'slug',
      label: 'Slug',
      type: 'text',
      required: true,
      placeholder: 'member-slug',
      help: 'URL-friendly version of the name'
    },
    {
      name: 'position',
      label: 'Position',
      type: 'text',
      required: true,
      placeholder: 'Job position/title'
    },
    {
      name: 'member_type',
      label: 'Member Type',
      type: 'select',
      required: true,
      options: [
        { value: 'management', label: 'Management' },
        { value: 'coaches', label: 'Coaches' },
        { value: 'staff', label: 'Staff' },
        { value: 'players', label: 'Players' }
      ]
    },
    {
      name: 'role',
      label: 'Team Role',
      type: 'select',
      options: roles?.results?.map(role => ({
        value: role.id,
        label: role.name
      })) || []
    },
    {
      name: 'bio',
      label: 'Biography',
      type: 'textarea',
      rows: 4,
      placeholder: 'Member biography',
      fullWidth: true
    },
    {
      name: 'photo',
      label: 'Photo',
      type: 'file',
      accept: 'image/*'
    },
    {
      name: 'email',
      label: 'Email',
      type: 'email',
      placeholder: 'member@example.com'
    },
    {
      name: 'phone',
      label: 'Phone',
      type: 'text',
      placeholder: '+93 xxx xxx xxx'
    },
    {
      name: 'join_date',
      label: 'Join Date',
      type: 'date',
      required: true
    },
    {
      name: 'is_active',
      label: 'Active',
      type: 'checkbox',
      defaultValue: true
    },
    {
      name: 'order',
      label: 'Display Order',
      type: 'number',
      defaultValue: 0,
      min: 0
    }
  ]

  return (
    <AdminLayout title={`Add ${memberType === 'player' ? 'Player' : 'Team Member'}`}>
      {/* Type Selector */}
      <div className="mb-8">
        <div className="flex space-x-4">
          <button
            onClick={() => setMemberType('player')}
            className={`px-4 py-2 rounded-lg font-medium ${
              memberType === 'player'
                ? 'bg-blue-600 text-white'
                : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
            }`}
          >
            Add Player
          </button>
          <button
            onClick={() => setMemberType('member')}
            className={`px-4 py-2 rounded-lg font-medium ${
              memberType === 'member'
                ? 'bg-blue-600 text-white'
                : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
            }`}
          >
            Add Team Member
          </button>
        </div>
      </div>

      <CrudForm
        endpoint={memberType === 'player' ? '/players/' : '/team-members/'}
        fields={memberType === 'player' ? playerFields : memberFields}
        title={memberType === 'player' ? 'Player' : 'Team Member'}
        backPath="/admin/team/"
        onSuccess={(data) => {
          console.log(`${memberType} created:`, data)
        }}
        onError={(error) => {
          console.error(`Failed to create ${memberType}:`, error)
        }}
      />
    </AdminLayout>
  )
}